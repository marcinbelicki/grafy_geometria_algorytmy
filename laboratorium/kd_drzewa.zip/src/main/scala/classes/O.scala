package classes

trait O

object Left extends O

object Right extends O

object NoTurn extends O

